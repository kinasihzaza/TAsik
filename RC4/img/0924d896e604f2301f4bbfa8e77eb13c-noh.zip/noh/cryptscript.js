$(document).ready( function () {
    var key = randomString(32);
    var fileName;

    $("#file").change(function () {
        $(".loading-file").hide();
        var start = performance.now();
        var fileInput = document.getElementById('file');
        var file = fileInput.files[0];
        fileName = $('#file').val().split('\\').pop() + ".encrypted";

        var reader = new FileReader();

        reader.onload = function(e) {
            var result = reader.result;
            var cipher = Ctr.encrypt(result, key);
            $("#lampiran").val(fileName + cipher);
            $(".loading-file").show();
            var end = performance.now();
            console.log("file = " + (end - start) + " milliseconds.");
        };
        reader.readAsDataURL(file);
    });

    $("#process").click(function (event){
        event.preventDefault();
        $(".secret").hide();
        var privatekey = $('#secret-key').val();
        var text = CKEDITOR.instances['pesan'].getData();

        var ajax = $.ajax({
            type: 'GET',
            url: 'api/publickey/' + $('#active-user').text() + '-' + $('#penerima').val(),
            success: function (data) {
                if (!data[0] || !data[1]) {
                    alert('username tidak ditemukan');
                }
                else {
                    if (!text && !fileName) {
                        $("#form-pesan").submit();
                    } else {
                        var publickeyPengirim = data[0].pbkey;
                        var publickeyPenerima = data[1].pbkey;
                        if (cekPrivateKey(privatekey, publickeyPengirim)) {
                            var t0Text = performance.now();
                            var senderPrivate = privatekey;
                            if (text) {
                                var ciphertext = Ctr.encrypt(text, key);
                            }

                            var recieverKey = crypt(key, senderPrivate, publickeyPenerima);
                            var senderKey = crypt(key, senderPrivate, publickeyPengirim);
                            var t1Text = performance.now();
                            // alert('text.length = ' + text.length + '\n' +
                            //     'ciphertext.length = ' + ciphertext.length + '\n' +
                            //     "text = " + (t1Text - t0Text) + " milliseconds.");
                            console.log(text.length);
                            console.log(ciphertext.length);
                            console.log(recieverKey.length);
                            console.log(senderKey.length);
                            console.log("text = " + (t1Text - t0Text) + " milliseconds.");
                            CKEDITOR.instances['pesan'].setData(ciphertext);
                            $('#receiverkey').val(recieverKey);
                            $('#senderkey').val(senderKey);
                            alert('done');
                            //$("#form-pesan").submit();
                        }
                        else {
                            alert('Private key tidak valid');
                            $(".secret").show();
                        }
                    }
                }
            },
            error: function () {
                alert('Penerima tidak boleh kosong');
            }
        });
    });
});

